--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cdms;
--
-- Name: cdms; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cdms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE cdms OWNER TO postgres;

\connect cdms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crimecase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crimecase (
    crimeid integer NOT NULL,
    city character varying(30) NOT NULL,
    street character varying(40) NOT NULL,
    zipcode integer NOT NULL,
    occurdate date NOT NULL,
    occurtime time without time zone NOT NULL,
    status character varying(6) NOT NULL,
    stationid integer NOT NULL,
    handlerid integer NOT NULL
);


ALTER TABLE public.crimecase OWNER TO postgres;

--
-- Name: crimecase_crimeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.crimecase_crimeid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crimecase_crimeid_seq OWNER TO postgres;

--
-- Name: crimecase_crimeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.crimecase_crimeid_seq OWNED BY public.crimecase.crimeid;


--
-- Name: crimetype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crimetype (
    typeid integer NOT NULL,
    crimeid integer NOT NULL,
    ibrcode character varying(5) NOT NULL
);


ALTER TABLE public.crimetype OWNER TO postgres;

--
-- Name: criminal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.criminal (
    criminalid integer NOT NULL,
    firstname character varying(20) NOT NULL,
    lastname character varying(20) NOT NULL,
    dob date NOT NULL,
    gender character(6) NOT NULL,
    race character varying(20) NOT NULL,
    prisonid integer NOT NULL
);


ALTER TABLE public.criminal OWNER TO postgres;

--
-- Name: criminal_criminalid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.criminal_criminalid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.criminal_criminalid_seq OWNER TO postgres;

--
-- Name: criminal_criminalid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.criminal_criminalid_seq OWNED BY public.criminal.criminalid;


--
-- Name: criminalvictimcase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.criminalvictimcase (
    crimeid integer NOT NULL,
    criminalid integer NOT NULL,
    victimid integer NOT NULL,
    prisonyears integer NOT NULL
);


ALTER TABLE public.criminalvictimcase OWNER TO postgres;

--
-- Name: handler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.handler (
    handlerid integer NOT NULL,
    firstname character varying(20) NOT NULL,
    lastname character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    password character varying(75) NOT NULL,
    role character(5) NOT NULL
);


ALTER TABLE public.handler OWNER TO postgres;

--
-- Name: handler_handlerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.handler_handlerid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.handler_handlerid_seq OWNER TO postgres;

--
-- Name: handler_handlerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.handler_handlerid_seq OWNED BY public.handler.handlerid;


--
-- Name: investigate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investigate (
    crimeid integer NOT NULL,
    policeid integer NOT NULL,
    startdate date NOT NULL,
    enddate date NOT NULL
);


ALTER TABLE public.investigate OWNER TO postgres;

--
-- Name: police; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.police (
    policeid integer NOT NULL,
    firstname character varying(20) NOT NULL,
    lastname character varying(20) NOT NULL,
    rank character varying(21) NOT NULL,
    dob date NOT NULL,
    joindate date NOT NULL,
    stationid integer NOT NULL
);


ALTER TABLE public.police OWNER TO postgres;

--
-- Name: police_policeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.police_policeid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.police_policeid_seq OWNER TO postgres;

--
-- Name: police_policeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.police_policeid_seq OWNED BY public.police.policeid;


--
-- Name: policestation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policestation (
    stationid integer NOT NULL,
    name character varying(35) NOT NULL,
    city character varying(13) NOT NULL
);


ALTER TABLE public.policestation OWNER TO postgres;

--
-- Name: policestation_stationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.policestation_stationid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.policestation_stationid_seq OWNER TO postgres;

--
-- Name: policestation_stationid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.policestation_stationid_seq OWNED BY public.policestation.stationid;


--
-- Name: prison; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prison (
    prisonid integer NOT NULL,
    prisonname character varying(66) NOT NULL,
    city character varying(30) NOT NULL,
    capacity integer NOT NULL
);


ALTER TABLE public.prison OWNER TO postgres;

--
-- Name: prison_prisonid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.prison_prisonid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prison_prisonid_seq OWNER TO postgres;

--
-- Name: prison_prisonid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.prison_prisonid_seq OWNED BY public.prison.prisonid;


--
-- Name: type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type (
    typeid integer NOT NULL,
    crimename character varying(20) NOT NULL
);


ALTER TABLE public.type OWNER TO postgres;

--
-- Name: type_typeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.type_typeid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_typeid_seq OWNER TO postgres;

--
-- Name: type_typeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.type_typeid_seq OWNED BY public.type.typeid;


--
-- Name: victim; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.victim (
    victimid integer NOT NULL,
    firstname character varying(20) NOT NULL,
    lastname character varying(20) NOT NULL,
    gender character(6) NOT NULL,
    dob date NOT NULL,
    race character varying(20) NOT NULL
);


ALTER TABLE public.victim OWNER TO postgres;

--
-- Name: victim_victimid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.victim_victimid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.victim_victimid_seq OWNER TO postgres;

--
-- Name: victim_victimid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.victim_victimid_seq OWNED BY public.victim.victimid;


--
-- Name: crimecase crimeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimecase ALTER COLUMN crimeid SET DEFAULT nextval('public.crimecase_crimeid_seq'::regclass);


--
-- Name: criminal criminalid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminal ALTER COLUMN criminalid SET DEFAULT nextval('public.criminal_criminalid_seq'::regclass);


--
-- Name: handler handlerid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.handler ALTER COLUMN handlerid SET DEFAULT nextval('public.handler_handlerid_seq'::regclass);


--
-- Name: police policeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.police ALTER COLUMN policeid SET DEFAULT nextval('public.police_policeid_seq'::regclass);


--
-- Name: policestation stationid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policestation ALTER COLUMN stationid SET DEFAULT nextval('public.policestation_stationid_seq'::regclass);


--
-- Name: prison prisonid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prison ALTER COLUMN prisonid SET DEFAULT nextval('public.prison_prisonid_seq'::regclass);


--
-- Name: type typeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type ALTER COLUMN typeid SET DEFAULT nextval('public.type_typeid_seq'::regclass);


--
-- Name: victim victimid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.victim ALTER COLUMN victimid SET DEFAULT nextval('public.victim_victimid_seq'::regclass);


--
-- Data for Name: crimecase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crimecase (crimeid, city, street, zipcode, occurdate, occurtime, status, stationid, handlerid) FROM stdin;
\.
COPY public.crimecase (crimeid, city, street, zipcode, occurdate, occurtime, status, stationid, handlerid) FROM '$$PATH$$/3413.dat';

--
-- Data for Name: crimetype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crimetype (typeid, crimeid, ibrcode) FROM stdin;
\.
COPY public.crimetype (typeid, crimeid, ibrcode) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: criminal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.criminal (criminalid, firstname, lastname, dob, gender, race, prisonid) FROM stdin;
\.
COPY public.criminal (criminalid, firstname, lastname, dob, gender, race, prisonid) FROM '$$PATH$$/3415.dat';

--
-- Data for Name: criminalvictimcase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.criminalvictimcase (crimeid, criminalid, victimid, prisonyears) FROM stdin;
\.
COPY public.criminalvictimcase (crimeid, criminalid, victimid, prisonyears) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: handler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.handler (handlerid, firstname, lastname, email, password, role) FROM stdin;
\.
COPY public.handler (handlerid, firstname, lastname, email, password, role) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: investigate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investigate (crimeid, policeid, startdate, enddate) FROM stdin;
\.
COPY public.investigate (crimeid, policeid, startdate, enddate) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: police; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.police (policeid, firstname, lastname, rank, dob, joindate, stationid) FROM stdin;
\.
COPY public.police (policeid, firstname, lastname, rank, dob, joindate, stationid) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: policestation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policestation (stationid, name, city) FROM stdin;
\.
COPY public.policestation (stationid, name, city) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: prison; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prison (prisonid, prisonname, city, capacity) FROM stdin;
\.
COPY public.prison (prisonid, prisonname, city, capacity) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type (typeid, crimename) FROM stdin;
\.
COPY public.type (typeid, crimename) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: victim; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.victim (victimid, firstname, lastname, gender, dob, race) FROM stdin;
\.
COPY public.victim (victimid, firstname, lastname, gender, dob, race) FROM '$$PATH$$/3419.dat';

--
-- Name: crimecase_crimeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.crimecase_crimeid_seq', 1, false);


--
-- Name: criminal_criminalid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.criminal_criminalid_seq', 1, false);


--
-- Name: handler_handlerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.handler_handlerid_seq', 1, false);


--
-- Name: police_policeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.police_policeid_seq', 1, false);


--
-- Name: policestation_stationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.policestation_stationid_seq', 1, false);


--
-- Name: prison_prisonid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prison_prisonid_seq', 1, false);


--
-- Name: type_typeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.type_typeid_seq', 1, false);


--
-- Name: victim_victimid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.victim_victimid_seq', 1, false);


--
-- Name: crimecase crimecase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimecase
    ADD CONSTRAINT crimecase_pkey PRIMARY KEY (crimeid);


--
-- Name: criminal criminal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminal
    ADD CONSTRAINT criminal_pkey PRIMARY KEY (criminalid);


--
-- Name: handler handler_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.handler
    ADD CONSTRAINT handler_email_key UNIQUE (email);


--
-- Name: handler handler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.handler
    ADD CONSTRAINT handler_pkey PRIMARY KEY (handlerid);


--
-- Name: police police_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.police
    ADD CONSTRAINT police_pkey PRIMARY KEY (policeid);


--
-- Name: policestation policestation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policestation
    ADD CONSTRAINT policestation_pkey PRIMARY KEY (stationid);


--
-- Name: prison prison_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prison
    ADD CONSTRAINT prison_pkey PRIMARY KEY (prisonid);


--
-- Name: type type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type
    ADD CONSTRAINT type_pkey PRIMARY KEY (typeid);


--
-- Name: victim victim_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.victim
    ADD CONSTRAINT victim_pkey PRIMARY KEY (victimid);


--
-- Name: crimecase_crimeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crimecase_crimeid_idx ON public.crimecase USING btree (crimeid);


--
-- Name: crimecase_handlerid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crimecase_handlerid_idx ON public.crimecase USING btree (handlerid);


--
-- Name: crimecase_stationid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crimecase_stationid_idx ON public.crimecase USING btree (stationid);


--
-- Name: crimetype_crimeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crimetype_crimeid_idx ON public.crimetype USING btree (crimeid);


--
-- Name: crimetype_typeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX crimetype_typeid_idx ON public.crimetype USING btree (typeid);


--
-- Name: criminal_criminalid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX criminal_criminalid_idx ON public.criminal USING btree (criminalid);


--
-- Name: criminal_prisonid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX criminal_prisonid_idx ON public.criminal USING btree (prisonid);


--
-- Name: criminalvictimcase_crimeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX criminalvictimcase_crimeid_idx ON public.criminalvictimcase USING btree (crimeid);


--
-- Name: criminalvictimcase_criminalid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX criminalvictimcase_criminalid_idx ON public.criminalvictimcase USING btree (criminalid);


--
-- Name: criminalvictimcase_victimid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX criminalvictimcase_victimid_idx ON public.criminalvictimcase USING btree (victimid);


--
-- Name: handler_handlerid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX handler_handlerid_idx ON public.handler USING btree (handlerid);


--
-- Name: investigate_crimeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX investigate_crimeid_idx ON public.investigate USING btree (crimeid);


--
-- Name: investigate_policeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX investigate_policeid_idx ON public.investigate USING btree (policeid);


--
-- Name: police_policeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX police_policeid_idx ON public.police USING btree (policeid);


--
-- Name: police_stationid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX police_stationid_idx ON public.police USING btree (stationid);


--
-- Name: policestation_stationid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX policestation_stationid_idx ON public.policestation USING btree (stationid);


--
-- Name: prison_prisonid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prison_prisonid_idx ON public.prison USING btree (prisonid);


--
-- Name: type_typeid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX type_typeid_idx ON public.type USING btree (typeid);


--
-- Name: victim_victimid_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX victim_victimid_idx ON public.victim USING btree (victimid);


--
-- Name: crimecase crimecase_handlerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimecase
    ADD CONSTRAINT crimecase_handlerid_fkey FOREIGN KEY (handlerid) REFERENCES public.handler(handlerid);


--
-- Name: crimecase crimecase_stationid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimecase
    ADD CONSTRAINT crimecase_stationid_fkey FOREIGN KEY (stationid) REFERENCES public.policestation(stationid);


--
-- Name: crimetype crimetype_crimeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimetype
    ADD CONSTRAINT crimetype_crimeid_fkey FOREIGN KEY (crimeid) REFERENCES public.crimecase(crimeid) ON DELETE CASCADE;


--
-- Name: crimetype crimetype_typeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crimetype
    ADD CONSTRAINT crimetype_typeid_fkey FOREIGN KEY (typeid) REFERENCES public.type(typeid) ON DELETE CASCADE;


--
-- Name: criminal criminal_prisonid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminal
    ADD CONSTRAINT criminal_prisonid_fkey FOREIGN KEY (prisonid) REFERENCES public.prison(prisonid);


--
-- Name: criminalvictimcase criminalvictimcase_crimeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminalvictimcase
    ADD CONSTRAINT criminalvictimcase_crimeid_fkey FOREIGN KEY (crimeid) REFERENCES public.crimecase(crimeid) ON DELETE CASCADE;


--
-- Name: criminalvictimcase criminalvictimcase_criminalid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminalvictimcase
    ADD CONSTRAINT criminalvictimcase_criminalid_fkey FOREIGN KEY (criminalid) REFERENCES public.criminal(criminalid) ON DELETE CASCADE;


--
-- Name: criminalvictimcase criminalvictimcase_victimid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.criminalvictimcase
    ADD CONSTRAINT criminalvictimcase_victimid_fkey FOREIGN KEY (victimid) REFERENCES public.victim(victimid) ON DELETE CASCADE;


--
-- Name: investigate investigate_crimeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigate
    ADD CONSTRAINT investigate_crimeid_fkey FOREIGN KEY (crimeid) REFERENCES public.crimecase(crimeid) ON DELETE CASCADE;


--
-- Name: investigate investigate_policeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigate
    ADD CONSTRAINT investigate_policeid_fkey FOREIGN KEY (policeid) REFERENCES public.police(policeid) ON DELETE CASCADE;


--
-- Name: police police_stationid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.police
    ADD CONSTRAINT police_stationid_fkey FOREIGN KEY (stationid) REFERENCES public.policestation(stationid);


--
-- PostgreSQL database dump complete
--

